Book$$crape™
Version 1.0

A small book-scraping application by MGpop.

SYSTEM REQUIREMENTS

- Windows
- Google Chrome
- Internet connection

Python, Selenium and the other Python dependencies do not need to be
installed separately.

HOW TO RUN

Extract the ZIP archive, then double-click BookScrape.exe.

Book$$crape uses Google Chrome to access book data. If Chrome cannot be
started or the website cannot be reached, some features will not be
available.

© 2026 MGpop
All rights reserved.

Made for fun.
Please don't take this too seriously.